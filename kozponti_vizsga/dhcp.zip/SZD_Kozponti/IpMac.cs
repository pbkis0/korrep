﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SZD_Kozponti
{
    class MacIp
    {
        public string mac;
        public string ip;
        
        public MacIp(string mac, string ip)
        {
            this.mac = mac;
            this.ip = ip;
        }

    }
}
