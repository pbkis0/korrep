﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SZD_Kozponti
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> excluded = new List<string>(); //0. lépés: Elkészítjük a listát, amiben tárolni fogjuk a fájlnak a sorait.
            using (StreamReader reader = new StreamReader(@"D:\Tanulmányok\Záróvizsga\1\excluded.csv")) // Megnyitjuk a fájlt.
            {
                while (!reader.EndOfStream) // Addig megyünk végig a sorain, amíg vége nincs(felkialto jel=tagadja) a fájlnak.
                {
                    string line = reader.ReadLine(); //Kiolvassuk a következő sort.
                    //var values = line.Split(';');

                    excluded.Add(line); //Betesszük a listába az előbb kiolvasott sort.
                }
            }

            List<MacIp> reserved = new List<MacIp>();
            using (StreamReader reader = new StreamReader(@"D:\Tanulmányok\Záróvizsga\1\reserved.csv"))
            {
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    string[] values = line.Split(';'); //Split=Darabolás, A kiolvasott sort feldaraboljuk a pontosvessző mentén.

                    reserved.Add(new MacIp(values[0], values[1]));
                }
            }

            List<MacIp> dhcp = new List<MacIp>();
            using (StreamReader reader = new StreamReader(@"D:\Tanulmányok\Záróvizsga\1\dhcp.csv"))
            {
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    string[] values = line.Split(';');

                    dhcp.Add(new MacIp(values[0], values[1]));
                }
            }

            List<Test> test = new List<Test>();
            using (StreamReader reader = new StreamReader(@"D:\Tanulmányok\Záróvizsga\1\test.csv"))
            {
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    string[] values = line.Split(' ');

                    test.Add(new Test(values[0], values[1]));
                }
            }

            foreach (Test sor in test) //Végig megyünk a test listán és az item nevezetű változóba kerül bele az adott sor.
            {
                if(sor.muvelet == "request") //Ha az adott művelet az request
                {
                    string mac = sor.parameter;

                    if(!macBenneVanEAListaban(mac, dhcp)) // ha nincs benne a mac cím a dhcp listában
                    {
                        if(macBenneVanEAListaban(mac, reserved)) // ha a mac cím benne van a reserved listában
                        {
                            string ip = getIpAListabol(mac, reserved);
                            if(!ipBenneVanEAListaban(ip, dhcp))
                            {
                                dhcp.Add(new MacIp(mac, ip));
                            }
                        }
                        else
                        {
                            dhcp.Add(new MacIp(mac, ipCimAdas(excluded, reserved, dhcp)));
                        }
                    }
                }
                else if (sor.muvelet == "release")
                {
                    foreach (MacIp par in dhcp) 
                    {
                        if (par.ip == sor.parameter) 
                        {
                            dhcp.Remove(par);
                            break;
                        }
                    }
                }
            }
        }

        public static string ipCimAdas(List<string> excluded, List<MacIp> reserved, List<MacIp> dhcp, int ip = 100)
        {
            string prefix = "192.168.10.";
            if (!ipBenneVanEAListaban(prefix + ip, dhcp)
                && !ipBenneVanEAKizartListaban(prefix + ip, excluded)
                && !ipBenneVanEAListaban(prefix + ip, reserved))
            {
                return prefix + ip;
            }
            ip = ip + 1;
            if (ip > 199)
            {
                //sikertelen
                throw new Exception("Nincs tobb cim");
            }
            else
            {
                return ipCimAdas(excluded, reserved, dhcp, ip);
            }
        }

        /**
         * Egy függvényt hozunk létre, amiben megnézzük, hogy az adott listában megtalálható-e
         * az adott mac cím. Egy igen/nem értéket akarunk kapni a végén
         * Paraméter a mac cím, és a lista, amiben keresünk
         **/
        public static bool macBenneVanEAListaban(string mac, List<MacIp> lista)
        {
            foreach (MacIp par in lista) // végigmegyünk a lista minden egyes elemén, ami MacIp-ket tartalmaz, és az adott sor neve a 'par'
            {
                if(par.mac == mac) // Megnézzük, hogy az adott párban található mac cím megegyezik-e a keresett mac címmel
                {
                    return true; //Ha igen, akkor egyből visszatérünk igazzal
                }
            }
            return false; //Amúgy, ha nem találtuk meg, akkor hamissal térünk vissza, mert nincs benne
        }

        public static bool ipBenneVanEAListaban(string ip, List<MacIp> lista)
        {
            foreach (MacIp par in lista) // végigmegyünk a lista minden egyes elemén, ami MacIp-ket tartalmaz, és az adott sor neve a 'par'
            {
                if (par.ip == ip) // Megnézzük, hogy az adott párban található mac cím megegyezik-e a keresett mac címmel
                {
                    return true; //Ha igen, akkor egyből visszatérünk igazzal
                }
            }
            return false; //Amúgy, ha nem találtuk meg, akkor hamissal térünk vissza, mert nincs benne
        }

        public static bool ipBenneVanEAKizartListaban(string ip, List<string> lista)
        {
            foreach (string par in lista) // végigmegyünk a lista minden egyes elemén, ami MacIp-ket tartalmaz, és az adott sor neve a 'par'
            {
                if (par == ip) // Megnézzük, hogy az adott párban található mac cím megegyezik-e a keresett mac címmel
                {
                    return true; //Ha igen, akkor egyből visszatérünk igazzal
                }
            }
            return false; //Amúgy, ha nem találtuk meg, akkor hamissal térünk vissza, mert nincs benne
        }

        public static string getIpAListabol(string mac, List<MacIp> lista)
        {
            foreach (MacIp par in lista) // végigmegyünk a lista minden egyes elemén, ami MacIp-ket tartalmaz, és az adott sor neve a 'par'
            {
                if (par.mac == mac) // Megnézzük, hogy az adott párban található mac cím megegyezik-e a keresett mac címmel
                {
                    return par.ip; //Ha igen, akkor egyből visszatérünk a keresett ip címmel
                }
            }
            return null; //Amúgy, ha nem találtuk meg, akkor null értékkel térünk vissza, mert nincs benne
        }
    }
}
