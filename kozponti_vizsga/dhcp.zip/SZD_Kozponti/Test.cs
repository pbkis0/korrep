﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SZD_Kozponti
{
    class Test
    {
        public string muvelet;
        public string parameter;

        public Test(string muvelet, string parameter)
        {
            this.muvelet = muvelet;
            this.parameter = parameter;
        }
    }
}
