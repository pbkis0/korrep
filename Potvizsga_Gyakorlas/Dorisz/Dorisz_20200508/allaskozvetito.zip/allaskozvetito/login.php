<?php

require_once 'config/init.php';


print_html("html/header.html");

menu();

print_html("html/login.html");

print_html("html/footer.html");

