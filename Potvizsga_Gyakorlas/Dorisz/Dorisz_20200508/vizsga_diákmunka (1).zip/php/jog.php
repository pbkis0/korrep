<?php

echo file_get_contents("../html/jog.html");