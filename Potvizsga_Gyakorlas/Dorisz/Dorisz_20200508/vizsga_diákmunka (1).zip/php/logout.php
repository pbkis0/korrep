<?php
session_start();
require('../config/functions.php');
session_destroy();


