<?php

function htmlKiir($html){
   print(file_get_contents($html));
}
