﻿CREATE TABLE `versenyszamok` 
(`id` INT NOT NULL AUTO_INCREMENT , 
`tevekenyseg_nev` VARCHAR(20) NOT NULL ,
`helyszin` VARCHAR(10) NOT NULL , 
PRIMARY KEY (`id`));

CREATE TABLE `tanulok` 
( `id` INT NOT NULL AUTO_INCREMENT , 
`vezeteknev` VARCHAR(20) NOT NULL , 
`keresztnev` VARCHAR(20) NOT NULL , 
`neme` VARCHAR(5) NOT NULL , 
`szuletesi_ido` DATE NOT NULL , 
`evfolyam` INT NOT NULL , 
PRIMARY KEY (`id`));

CREATE TABLE `kimitsportol` 
( `versenyszamokid` INT NOT NULL , 
`tanulokid` INT NOT NULL );