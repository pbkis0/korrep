﻿1.
CREATE DATABASE montypython CHARACTER SET=utf8 COLLATE utf8_hungarian_ci;

3.
SELECT nev
FROM epizodok
WHERE sorozat="1/5";

4.
SELECT COUNT(nev) AS epizodok_szama
FROM epizodok;

5.
SELECT DISTINCT szinesz
FROM forgatokonyv
WHERE szinesz is not null
ORDER BY szinesz;

6.
SELECT reszletek
FROM tipusok INNER JOIN forgatokonyv ON tipusok.id=forgatokonyv.tipusid
WHERE szinesz = "John Cleese" and resz="Italian lesson" and tipus="dialógus";

7.
SELECT szinesz, COUNT(reszletek) AS bejegyzesek_szama
FROM tipusok INNER JOIN forgatokonyv ON tipusok.id=forgatokonyv.tipusid
WHERE tipus="dialógus"
GROUP BY szinesz
ORDER BY bejegyzesek_szama DESC limit 1;

